import subprocess,json
from pathlib import Path
r=Path(__file__).resolve().parent
for level in [0,3]:
 binary=r/f'probe-{level}'
 subprocess.run(json.loads((r/'compile.json').read_text())+['-C',f'opt-level={level}','-o',str(binary)],check=True)
 with (r/f'result-{level}.csv').open('w') as f: subprocess.run([str(binary)],stdout=f,check=True)
 print((r/f'result-{level}.csv').read_text(),flush=True)
