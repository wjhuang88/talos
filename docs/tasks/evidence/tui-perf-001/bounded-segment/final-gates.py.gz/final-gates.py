import json,subprocess,time
from pathlib import Path
r=Path(__file__).resolve().parent
rows=[]
for name,cmd in [('preflight',['./scripts/release_preflight.sh']),('xwin',['/usr/bin/cargo','xwin','check','--locked','-p','talos-tui','--tests','--target','x86_64-pc-windows-msvc'])]:
 start=time.monotonic()
 with (r/(name+'.log')).open('w') as out: p=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT)
 rows.append({'name':name,'command':cmd,'exit_code':p.returncode,'seconds':time.monotonic()-start})
 (r/'final-gates.json').write_text(json.dumps(rows,indent=2));print(rows[-1],flush=True)
 if p.returncode: raise SystemExit(p.returncode)
