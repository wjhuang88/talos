import json,statistics
from pathlib import Path
r=Path(__file__).resolve().parent
rows=json.loads((r/'active-pairs.json').read_text())
assert len(rows)==12
out=[]
for profile in ['debug','release']:
 previous=[x for x in rows if x['profile']==profile and x['variant']=='previous'];current=[x for x in rows if x['profile']==profile and x['variant']=='bounded']
 assert len(previous)==len(current)==3
 baseline=statistics.median(x['cpu_percent'] for x in previous);candidate=statistics.median(x['cpu_percent'] for x in current)
 psslimit=max(x['peak_pss_kib'] for x in previous)*1.2+8192
 limits=(20000000,35000000) if profile=='debug' else (10000000,20000000)
 failed=[x['round'] for x in current if x['p95']['upper_ns']>limits[0] or x['p99']['upper_ns']>limits[1]]
 out.append(dict(profile=profile,baseline_cpu_median=baseline,candidate_cpu_median=candidate,cpu_ratio=candidate/baseline,cpu_pass=candidate<=baseline*1.2,candidate_peak_pss_kib=max(x['peak_pss_kib'] for x in current),pss_limit_kib=psslimit,pss_pass=all(x['peak_pss_kib']<=psslimit for x in current),input_failed_rounds=failed,input_pass=not failed,skipped=sum(x['skipped'] for x in current)))
(r/'active-summary.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
