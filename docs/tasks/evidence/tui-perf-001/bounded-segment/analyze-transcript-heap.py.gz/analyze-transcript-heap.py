import json,re,statistics
from pathlib import Path
r=Path(__file__).resolve().parent
s=(r/'heap-transcript-commit-massif.txt').read_text();pairs=[(float(t),int(b)) for t,b in re.findall(r'time=([\d.]+)\nmem_heap_B=(\d+)',s)]
windows=[]
for start in range(30,300,30):
 vals=[b for t,b in pairs if start<=t<start+30]
 if vals:windows.append(dict(start_seconds=start,samples=len(vals),min_bytes=min(vals),median_bytes=statistics.median(vals),max_bytes=max(vals)))
m=json.loads((r/'heap-transcript-commit-metrics.json').read_text());result=dict(windows=windows,median_deltas=[b['median_bytes']-a['median_bytes'] for a,b in zip(windows,windows[1:])],actual_rebuilds=m['steady_stages']['history_rebuild']['count'],steady_seconds=m['steady_elapsed_ns']/1e9,limitation='massif detailed tree does not attribute bytes; finite total-growth observation only')
(r/'heap-transcript-windows.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
