# Detailed heap export limitation

heaptrack_print --massif-detailed-freq30 --massif-threshold0.1 emits correct
nonzero mem_heap_B totals but detailed tree roots have only a zero-byte
"all below threshold" child. Therefore these tree snapshots cannot attribute
live bytes to transcript/projection caches. This is an observed export limitation,
not evidence that category allocations are zero. Text backtraces remain present
in the ordinary analysis. Finite total-heap stability can be reported separately;
category attribution remains unverified until an independently reconciled report
is available. Do not sum overlapping merged peak backtraces: heaptrack_print help
explicitly warns merged peak consumption is not correct.
