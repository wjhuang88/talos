# Transcript input long-tail observation

First bounded Debug sample fails P99 (upper479.239045ms; budget35ms).
Coverage is valid:61 probes,0 skipped, maximum sample gap0.389s. Preserve as
failed acceptance, not an excluded or passing round.

The same sample reports frame_preparation max476.541768ms, draw max479.155330ms,
history_rebuild max0.065496ms, flush max0.016214ms. These aggregate maxima do not
identify a specific frame, but make projection CPU an unsupported explanation.
Frame preparation performs view/layout/cache work; no newly introduced filesystem
or network operation appears in the293ce0a2 diff (only bounded projection probe).

Leaf cgroup IO full total rises248575->907105us within the steady window; no leaf
CPU throttle or memory.high event. Host IO PSI later observed some78%/full67%.
These are time-associated pressure observations, not causal attribution of the
476ms frame. File faults, scheduling or component work remain hypotheses. Existing
sampler does not capture per-frame thread CPU, major faults or off-CPU stack data.

Later same-binary Debug rounds pass with P99upper3.422221/3.461222ms. They do not
erase the failed first round or prove absence of a rare product issue. Do not
repeat the matrix unchanged merely to obtain green. Next diagnostic should pair
frame wall time with thread CPU/fault or off-CPU evidence, under the same limits,
without loosening35ms or changing production behavior on this evidence alone.
