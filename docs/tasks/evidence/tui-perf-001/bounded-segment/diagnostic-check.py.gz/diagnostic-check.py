import subprocess,time,json
from pathlib import Path
r=Path(__file__).resolve().parent
cmd=['/usr/bin/cargo','test','--locked','-p','talos-agent','--lib','session::tests::cooperative_recovered_sources_bind_long_history_and_refuse_foreign_or_expired','--','--exact','--nocapture']
t=time.monotonic()
with (r/'binding-diagnostic-test.log').open('w') as out:p=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT)
(r/'binding-diagnostic-test.json').write_text(json.dumps({'command':cmd,'exit_code':p.returncode,'seconds':time.monotonic()-t},indent=2));print((r/'binding-diagnostic-test.json').read_text(),flush=True)
raise SystemExit(p.returncode)
