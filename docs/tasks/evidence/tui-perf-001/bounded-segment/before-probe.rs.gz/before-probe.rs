use crossterm::style::Color as CColor;
use unicode_width::{UnicodeWidthChar,UnicodeWidthStr};
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub(crate) struct HistoryAttrs {
    pub(crate) bold: bool,
    pub(crate) italic: bool,
    pub(crate) underlined: bool,
    pub(crate) dim: bool,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct HistorySegment {
    pub(crate) text: String,
    pub(crate) fg: Option<CColor>,
    pub(crate) attrs: HistoryAttrs,
}

impl HistorySegment {
    pub(crate) fn raw(text: impl Into<String>) -> Self {
        Self {
            text: text.into(),
            fg: None,
            attrs: HistoryAttrs::default(),
        }
    }

    pub(crate) fn styled(text: impl Into<String>, fg: Option<CColor>, attrs: HistoryAttrs) -> Self {
        Self {
            text: text.into(),
            fg,
            attrs,
        }
    }
}

#[derive(Clone, Debug, Eq)]
pub(crate) struct ScrollbackLine {
    pub(crate) text: String,
    pub(crate) segments: Vec<HistorySegment>,
    pub(crate) bg: Option<CColor>,
    pub(crate) fill: Option<HistorySegment>,
    pub(crate) continuation_indent: usize,
}

impl PartialEq for ScrollbackLine {
    fn eq(&self, other: &Self) -> bool {
        self.text == other.text
            && self.bg == other.bg
            && self.fill == other.fill
            && self.continuation_indent == other.continuation_indent
    }
}

impl ScrollbackLine {
    pub(crate) fn plain(text: impl Into<String>, bg: Option<CColor>) -> Self {
        let text = text.into();
        Self {
            segments: vec![HistorySegment::raw(text.clone())],
            text,
            bg,
            fill: None,
            continuation_indent: 0,
        }
    }

    pub(crate) fn styled(segments: Vec<HistorySegment>, bg: Option<CColor>) -> Self {
        Self::styled_with_fill(segments, bg, None)
    }

    pub(crate) fn styled_with_fill(
        segments: Vec<HistorySegment>,
        bg: Option<CColor>,
        fill: Option<HistorySegment>,
    ) -> Self {
        let text = segments
            .iter()
            .map(|segment| segment.text.as_str())
            .collect::<String>();
        Self {
            text,
            segments,
            bg,
            fill,
            continuation_indent: 0,
        }
    }
}

struct ProjectedLineChunk {
    synthetic_prefix: usize,
    line: ScrollbackLine,
    logical_start: usize,
    logical_end: usize,
}

fn project_fill_segment(fill: &HistorySegment, available_cells: usize) -> Option<HistorySegment> {
    if available_cells == 0 || fill.text.is_empty() {
        return None;
    }
    let mut text = String::new();
    let mut used = 0usize;
    let scalars: Vec<char> = fill.text.chars().collect();
    if scalars.is_empty() {
        return None;
    }
    while used < available_cells {
        let mut progressed = false;
        for ch in &scalars {
            let width = UnicodeWidthChar::width(*ch).unwrap_or(0);
            if width == 0 {
                continue;
            }
            if used.saturating_add(width) > available_cells {
                continue;
            }
            text.push(*ch);
            used = used.saturating_add(width);
            progressed = true;
            if used == available_cells {
                break;
            }
        }
        if !progressed {
            break;
        }
    }
    (!text.is_empty()).then(|| HistorySegment::styled(text, fill.fg, fill.attrs))
}
fn baseline(line: &ScrollbackLine, width: u16) -> Vec<ProjectedLineChunk> {
    let capacity = usize::from(width);
    let mut rows = Vec::new();
    let mut current = Vec::<HistorySegment>::new();
    let mut used = 0usize;
    let mut logical_offset = 0usize;
    let mut row_start = 0usize;
    let mut synthetic_prefix = 0usize;

    for segment in &line.segments {
        for (byte_offset, ch) in segment.text.char_indices() {
            let char_width = UnicodeWidthChar::width(ch).unwrap_or(0);
            // A double-width scalar cannot be represented at width one. This is
            // projection-only; the original scalar remains in TranscriptStore.
            if char_width > capacity {
                if !current.is_empty() {
                    rows.push(ProjectedLineChunk {
                        synthetic_prefix,
                        line: ScrollbackLine::styled(std::mem::take(&mut current), line.bg),
                        logical_start: row_start,
                        logical_end: logical_offset,
                    });
                    used = 0;
                    synthetic_prefix = 0;
                }
                rows.push(ProjectedLineChunk {
                    synthetic_prefix: 0,
                    line: ScrollbackLine::plain("…", line.bg),
                    logical_start: logical_offset,
                    logical_end: logical_offset + 1,
                });
                logical_offset += 1;
                row_start = logical_offset;
                continue;
            }
            if used > 0 && used.saturating_add(char_width) > capacity {
                rows.push(ProjectedLineChunk {
                    synthetic_prefix,
                    line: ScrollbackLine::styled(std::mem::take(&mut current), line.bg),
                    logical_start: row_start,
                    logical_end: logical_offset,
                });
                // Leave enough room for the next scalar even in a tiny viewport.
                synthetic_prefix = line
                    .continuation_indent
                    .min(capacity.saturating_sub(char_width.max(1)));
                used = synthetic_prefix;
                if synthetic_prefix > 0 {
                    current.push(HistorySegment::raw(" ".repeat(synthetic_prefix)));
                }
                row_start = logical_offset;
            }
            if let Some(last) = current.last_mut()
                && last.fg == segment.fg
                && last.attrs == segment.attrs
            {
                last.text.push(ch);
            } else {
                // Bound speculative capacity to one viewport row and remaining
                // source bytes. Zero-width runs may grow normally beyond it.
                let mut text = String::with_capacity(
                    (segment.text.len() - byte_offset)
                        .min(capacity.saturating_sub(used).saturating_mul(4)),
                );
                text.push(ch);
                current.push(HistorySegment::styled(text, segment.fg, segment.attrs));
            }
            used = used.saturating_add(char_width);
            logical_offset += 1;
        }
    }
    if !current.is_empty() {
        rows.push(ProjectedLineChunk {
            synthetic_prefix,
            line: ScrollbackLine::styled(current, line.bg),
            logical_start: row_start,
            logical_end: logical_offset,
        });
    }
    if rows.is_empty() && line.fill.is_none() {
        return vec![ProjectedLineChunk {
            synthetic_prefix: 0,
            line: line.clone(),
            logical_start: 0,
            logical_end: logical_offset,
        }];
    }
    if rows.is_empty() {
        rows.push(ProjectedLineChunk {
            synthetic_prefix: 0,
            line: ScrollbackLine::styled(Vec::new(), line.bg),
            logical_start: 0,
            logical_end: 0,
        });
    }
    if let Some(fill) = &line.fill {
        let last_index = rows.len().saturating_sub(1);
        for (index, row) in rows.iter_mut().enumerate() {
            // Background padding covers every visual row, including the spare
            // cell before a wide character wraps. Decorative fills stay last-only.
            if index != last_index && fill.text != " " {
                continue;
            }
            let used = UnicodeWidthStr::width(row.line.text.as_str());
            if let Some(fill) = project_fill_segment(fill, capacity.saturating_sub(used)) {
                row.line.segments.push(fill);
                row.line.text = row
                    .line
                    .segments
                    .iter()
                    .map(|segment| segment.text.as_str())
                    .collect();
            }
        }
    }
    rows
}
fn candidate(line: &ScrollbackLine, width: u16) -> Vec<ProjectedLineChunk> {
    let capacity = usize::from(width);
    let mut rows = Vec::new();
    let mut current = Vec::<HistorySegment>::new();
    let mut used = 0usize;
    let mut logical_offset = 0usize;
    let mut row_start = 0usize;
    let mut synthetic_prefix = 0usize;

    for segment in &line.segments {
        // Most history segments fit on the current row. Keep scalar-width
        // semantics (including combining marks), but copy their UTF-8 bytes
        // once instead of repeatedly checking style and pushing each scalar.
        let fits = segment
            .text
            .chars()
            .try_fold((used, 0usize), |(cells, scalars), ch| {
                let width = UnicodeWidthChar::width(ch).unwrap_or(0);
                let next = cells.saturating_add(width);
                (width <= capacity && next <= capacity).then_some((next, scalars + 1))
            });
        if let Some((cells, scalars)) = fits
            && scalars > 0
        {
            if let Some(last) = current.last_mut()
                && last.fg == segment.fg
                && last.attrs == segment.attrs
            {
                last.text.push_str(&segment.text);
            } else {
                current.push(segment.clone());
            }
            used = cells;
            logical_offset += scalars;
            continue;
        }
        for (byte_offset, ch) in segment.text.char_indices() {
            let char_width = UnicodeWidthChar::width(ch).unwrap_or(0);
            // A double-width scalar cannot be represented at width one. This is
            // projection-only; the original scalar remains in TranscriptStore.
            if char_width > capacity {
                if !current.is_empty() {
                    rows.push(ProjectedLineChunk {
                        synthetic_prefix,
                        line: ScrollbackLine::styled(std::mem::take(&mut current), line.bg),
                        logical_start: row_start,
                        logical_end: logical_offset,
                    });
                    used = 0;
                    synthetic_prefix = 0;
                }
                rows.push(ProjectedLineChunk {
                    synthetic_prefix: 0,
                    line: ScrollbackLine::plain("…", line.bg),
                    logical_start: logical_offset,
                    logical_end: logical_offset + 1,
                });
                logical_offset += 1;
                row_start = logical_offset;
                continue;
            }
            if used > 0 && used.saturating_add(char_width) > capacity {
                rows.push(ProjectedLineChunk {
                    synthetic_prefix,
                    line: ScrollbackLine::styled(std::mem::take(&mut current), line.bg),
                    logical_start: row_start,
                    logical_end: logical_offset,
                });
                // Leave enough room for the next scalar even in a tiny viewport.
                synthetic_prefix = line
                    .continuation_indent
                    .min(capacity.saturating_sub(char_width.max(1)));
                used = synthetic_prefix;
                if synthetic_prefix > 0 {
                    current.push(HistorySegment::raw(" ".repeat(synthetic_prefix)));
                }
                row_start = logical_offset;
            }
            if let Some(last) = current.last_mut()
                && last.fg == segment.fg
                && last.attrs == segment.attrs
            {
                last.text.push(ch);
            } else {
                // Bound speculative capacity to one viewport row and remaining
                // source bytes. Zero-width runs may grow normally beyond it.
                let mut text = String::with_capacity(
                    (segment.text.len() - byte_offset)
                        .min(capacity.saturating_sub(used).saturating_mul(4)),
                );
                text.push(ch);
                current.push(HistorySegment::styled(text, segment.fg, segment.attrs));
            }
            used = used.saturating_add(char_width);
            logical_offset += 1;
        }
    }
    if !current.is_empty() {
        rows.push(ProjectedLineChunk {
            synthetic_prefix,
            line: ScrollbackLine::styled(current, line.bg),
            logical_start: row_start,
            logical_end: logical_offset,
        });
    }
    if rows.is_empty() && line.fill.is_none() {
        return vec![ProjectedLineChunk {
            synthetic_prefix: 0,
            line: line.clone(),
            logical_start: 0,
            logical_end: logical_offset,
        }];
    }
    if rows.is_empty() {
        rows.push(ProjectedLineChunk {
            synthetic_prefix: 0,
            line: ScrollbackLine::styled(Vec::new(), line.bg),
            logical_start: 0,
            logical_end: 0,
        });
    }
    if let Some(fill) = &line.fill {
        let last_index = rows.len().saturating_sub(1);
        for (index, row) in rows.iter_mut().enumerate() {
            // Background padding covers every visual row, including the spare
            // cell before a wide character wraps. Decorative fills stay last-only.
            if index != last_index && fill.text != " " {
                continue;
            }
            let used = UnicodeWidthStr::width(row.line.text.as_str());
            if let Some(fill) = project_fill_segment(fill, capacity.saturating_sub(used)) {
                row.line.segments.push(fill);
                row.line.text = row
                    .line
                    .segments
                    .iter()
                    .map(|segment| segment.text.as_str())
                    .collect();
            }
        }
    }
    rows
}
fn check(a:&[ProjectedLineChunk],b:&[ProjectedLineChunk]) {assert_eq!(a.len(),b.len());for (x,y) in a.iter().zip(b) {assert_eq!((&x.line.text,&x.line.segments,x.line.bg,&x.line.fill,x.logical_start,x.logical_end,x.synthetic_prefix),(&y.line.text,&y.line.segments,y.line.bg,&y.line.fill,y.logical_start,y.logical_end,y.synthetic_prefix));}}
fn bench(f:fn(&ScrollbackLine,u16)->Vec<ProjectedLineChunk>,line:&ScrollbackLine,width:u16)->f64 {let start=std::time::Instant::now();let mut n=0;while start.elapsed().as_millis()<150 {std::hint::black_box(f(std::hint::black_box(line),width));n+=1;}start.elapsed().as_nanos() as f64/n as f64}
fn main(){
 let cases=[("ascii-wrap","x".repeat(32768)),("cjk-wrap","中文".repeat(16384)),("zero-prefix-wrap",format!("{}{}","\u{301}".repeat(32768),"x".repeat(256))),("zero-only","\u{301}".repeat(32768)),("emoji-wrap","🦀e\u{301}".repeat(8192)),("short-fit","normal 中文 e\u{301}".into())];
 for (name,text) in cases {
 let line=ScrollbackLine::plain(text,None);
 for width in [0,1,2,7,80,120] {check(&baseline(&line,width),&candidate(&line,width));}
 for round in 0..3 {let (b,c)=if round%2==0 {(bench(baseline,&line,80),bench(candidate,&line,80))}else{let c=bench(candidate,&line,80);(bench(baseline,&line,80),c)};println!("{name},{round},{b:.0},{c:.0},{:.4}",c/b);}
 }
}
