import subprocess,json,shutil,hashlib,sys
from pathlib import Path
r=Path(__file__).resolve().parent
with (r/'build-debug.log').open('w') as log: subprocess.run(['/usr/bin/cargo','build','--locked','-p','talos-tui','--example','tui_perf_replay'],stdout=log,stderr=subprocess.STDOUT,check=True)
shutil.copy2('/home/wjhuang/WorkSpace/personal/talos/target/debug/examples/tui_perf_replay',r/'debug')
p=r/'receipt.json';d=json.loads(p.read_text());d['debug_sha256']=hashlib.sha256((r/'debug').read_bytes()).hexdigest();p.write_text(json.dumps(d,indent=2))
subprocess.run([sys.executable,str(r/'resize-input-followup.py')],check=True)
