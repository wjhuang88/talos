import subprocess,json
from pathlib import Path
r=Path(__file__).resolve().parent
subprocess.run(json.loads((r/"compile.json").read_text()),check=True)
with (r/"result.log").open("w") as f: subprocess.run([str(r/"probe")],stdout=f,stderr=subprocess.STDOUT,check=True)
print((r/"result.log").read_text())
