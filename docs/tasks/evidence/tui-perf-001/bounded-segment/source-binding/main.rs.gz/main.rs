#[path="source.rs"] mod source;
use talos_core::message::Message;
use std::time::{Duration,Instant};
fn main() {
 let rt=tokio::runtime::Builder::new_current_thread().enable_time().build().expect("runtime");
 rt.block_on(async {
  let mut raw: Vec<_>=(0..8300).map(|i|Message::User{content:format!("original {i}")}).collect();
  let previous=source::HistorySource::bind_content_until(0,8300,&raw,tokio::time::Instant::now()+Duration::from_secs(10)).await.expect("setup");
  raw.push(Message::User{content:"continue".into()});
  for workers in [64] {
   let mut tasks=Vec::new();
   for _ in 0..workers {tasks.push(tokio::spawn(async {loop {std::hint::black_box((0..100).fold(0u64,|a,b|a.wrapping_add(b)));tokio::task::yield_now().await;}}));}
   let start=Instant::now();
   let result=source::HistorySource::bind_committed_until(0,&raw,Some(&previous),8300,Some("fixture"),&["next".into()],tokio::time::Instant::now()+Duration::from_secs(2)).await;
   println!("workers={workers} success={} elapsed_ms={}",result.is_some(),start.elapsed().as_millis());
   for task in tasks {task.abort(); let _=task.await;}
  }
 });
}
