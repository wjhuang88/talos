import os,sys,json,subprocess,statistics
from pathlib import Path
root=Path(__file__).resolve().parent
repo=Path('/home/wjhuang/WorkSpace/personal/talos/target/tui-perf-acceptance')
sys.path.insert(0,str(repo/'scripts'))
from tui_perf_validation import validate_sample,validate_metrics
from summarize_tui_perf import percentile_bounds
rows=[]
# Compare the changed projection workload against the preceding immutable candidate.
# This isolates the byte-bound correction; it is not a new original-baseline matrix.
for profile in ['debug','release']:
 for round in range(3):
  for variant in (['previous','bounded'] if round%2==0 else ['bounded','previous']):
   binary=(root.parent/'segment-copy-1eabf296'/profile) if variant=='previous' else root/profile
   name=f'active-{profile}-{round}-{variant}'
   env=dict(os.environ,TALOS_TUI_METRICS=str(root/(name+'-metrics.json')),TALOS_TUI_METRICS_WARMUP_MS='5000')
   subprocess.run([sys.executable,str(repo/'scripts/measure_tui_perf.py'),str(binary),'--scenario','transcript-commit','--history','10000','--seconds','35','--warmup','5','--input-probe','--cgroup','--output',str(root/(name+'-sample.json'))],env=env,check=True)
   s=json.loads((root/(name+'-sample.json')).read_text());coverage=validate_sample(root/(name+'-sample.json'),35,5);m=validate_metrics(root/(name+'-metrics.json'),'transcript-commit',s['action_count'],5000,35)
   ss=[v for v in s['samples'] if s['ready_seconds']+5<=v['seconds']<=s['ready_seconds']+35];a,b=ss[0],ss[-1]
   rows.append(dict(profile=profile,round=round,variant=variant,binary_sha256=s['binary_sha256'],coverage=coverage,cpu_percent=100*(b['cpu_seconds']-a['cpu_seconds'])/(b['seconds']-a['seconds']),peak_pss_kib=max(v['pss_kib'] for v in ss),p95=percentile_bounds(m['steady_stages']['input_to_submit'],95),p99=percentile_bounds(m['steady_stages']['input_to_submit'],99),probes=s['input_probe_count'],skipped=s['input_probe_skipped_count']))
   (root/'active-pairs.json').write_text(json.dumps(rows,indent=2));print(rows[-1],flush=True)
