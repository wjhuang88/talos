import subprocess,shutil,hashlib,json,sys
from pathlib import Path
r=Path(__file__).resolve().parent
with (r/'build-release.log').open('w') as f: subprocess.run(['/usr/bin/cargo','build','--locked','--release','-p','talos-tui','--example','tui_perf_replay'],stdout=f,stderr=subprocess.STDOUT,check=True)
shutil.copy2('/home/wjhuang/WorkSpace/personal/talos/target/release/examples/tui_perf_replay',r/'release')
(r/'release-receipt.json').write_text(json.dumps({'implementation_commit':'293ce0a2','profile':'repository default Release','binary_sha256':hashlib.sha256((r/'release').read_bytes()).hexdigest()},indent=2))
subprocess.run([sys.executable,str(r/'release-measure.py')],check=True)
