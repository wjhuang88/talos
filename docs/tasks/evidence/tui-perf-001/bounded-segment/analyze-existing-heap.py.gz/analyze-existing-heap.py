import subprocess,re,statistics,json
from pathlib import Path
r=Path(__file__).resolve().parent
with (r/'heap-resize-analysis.txt').open('w') as out:
 subprocess.run(['/tmp/talos-perf-profiler/usr/bin/heaptrack_print',str(r/'heap-resize.zst'),'-n','5','-M',str(r/'heap-resize-massif.txt'),'--massif-detailed-freq','30','--massif-threshold','0.1'],stdout=out,check=True)
s=(r/'heap-resize-massif.txt').read_text();pairs=[(float(t),int(b)) for t,b in re.findall(r'time=([\d.]+)\nmem_heap_B=(\d+)',s)]
windows=[]
for start in range(30,300,30):
 vals=[b for t,b in pairs if start<=t<start+30]
 if vals:windows.append(dict(start_seconds=start,samples=len(vals),min_bytes=min(vals),median_bytes=statistics.median(vals),max_bytes=max(vals)))
result=dict(acceptance='coverage failed; diagnostic only',actual_resizes=569,windows=windows,median_delta_bytes=windows[-1]['median_bytes']-windows[0]['median_bytes'])
(r/'heap-resize-windows.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
