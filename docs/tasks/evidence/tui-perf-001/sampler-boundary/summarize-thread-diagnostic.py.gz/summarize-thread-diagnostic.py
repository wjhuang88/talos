import json,sys
from pathlib import Path
sys.path.insert(0,'/home/wjhuang/WorkSpace/personal/talos/target/tui-perf-acceptance/scripts')
from summarize_tui_perf import percentile_bounds
from tui_perf_validation import validate_sample,validate_metrics
r=Path('/home/wjhuang/WorkSpace/personal/talos/target/tui-perf-artifacts/sampler-boundary-b007a547')
s=json.loads((r/'thread-diagnostic-sample.json').read_text()); t=json.loads((r/'thread-diagnostic-sample.json.threads.json').read_text())
coverage=validate_sample(r/'thread-diagnostic-sample.json',35,5)
m=validate_metrics(r/'thread-diagnostic-metrics.json','transcript-commit',0,5000,35)
steady=[x for x in t['samples'] if s['ready_seconds']+5<=x['seconds']<=s['ready_seconds']+35]
deltas=[]
for a,b in zip(steady,steady[1:]):
 old={x['tid']:x for x in a['threads']}
 for x in b['threads']:
  if x['tid'] not in old:continue
  p=old[x['tid']]
  deltas.append({k:x[k]-p[k] for k in ['runtime_ns','runqueue_wait_ns','minor_faults','major_faults']})
result=dict(coverage=coverage,binary_sha256=s['binary_sha256'],p99=percentile_bounds(m['steady_stages']['input_to_submit'],99),frame_preparation_max_ns=m['steady_stages']['frame_preparation']['max_ns'],draw_max_ns=m['steady_stages']['draw']['max_ns'],thread_sample_count=len(steady),max_sample_gap_seconds=max(b['seconds']-a['seconds'] for a,b in zip(steady,steady[1:])),max_thread_interval_deltas={k:max(x[k] for x in deltas) for k in deltas[0]},observed_major_faults=sum(x['major_faults'] for x in deltas),input_probes=s['input_probe_count'],skipped_probes=s['input_probe_skipped_count'],wall_seconds=37.640,cpu_seconds=2.584,peak_service_memory='166.6MiB',swap_bytes=0,conclusion='479ms tail did not reproduce. Diagnostic observer changes timing; this run cannot erase prior failure or establish its cause. No per-frame CPU/stack attribution.')
(r/'thread-diagnostic-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
