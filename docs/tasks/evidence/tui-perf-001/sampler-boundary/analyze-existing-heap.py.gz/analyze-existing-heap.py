import re,statistics,json,sys
from pathlib import Path
r=Path(__file__).resolve().parent
sys.path.insert(0, '/home/wjhuang/WorkSpace/personal/talos/target/tui-perf-acceptance/scripts')
from tui_perf_validation import validate_sample, validate_metrics
sample=json.loads((r/'heap-resize-sample.json').read_text())
validate_sample(r/'heap-resize-sample.json',305,5)
metrics=validate_metrics(r/'heap-resize-metrics.json','resize',sample['action_count'],5000,305)
s=(r/'heap-resize-massif.txt').read_text();pairs=[(float(t),int(b)) for t,b in re.findall(r'time=([\d.]+)\nmem_heap_B=(\d+)',s)]
windows=[]
for start in range(30,300,30):
 vals=[b for t,b in pairs if start<=t<start+30]
 if vals:windows.append(dict(start_seconds=start,samples=len(vals),min_bytes=min(vals),median_bytes=statistics.median(vals),max_bytes=max(vals)))
result=dict(acceptance='coverage passed; finite heap observation only',actual_screen_size_changes=metrics['steady_stages']['screen_resize']['count'],raw_resize_events=metrics['steady_stages']['resize']['count'],windows=windows,median_delta_bytes=windows[-1]['median_bytes']-windows[0]['median_bytes'])
(r/'heap-resize-windows.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
