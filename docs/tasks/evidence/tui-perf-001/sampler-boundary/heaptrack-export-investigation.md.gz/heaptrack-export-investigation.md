# Heaptrack 1.5.0 detailed export investigation

Primary sources retrieved2026-11-13:
- https://github.com/KDE/heaptrack/blob/v1.5.0/src/analyze/print/heaptrack_print.cpp
- https://github.com/KDE/heaptrack/blob/v1.5.0/src/analyze/accumulatedtracedata.cpp

heaptrack_print.cpp handleTimeStamp returns unless pass==FirstPass, then writes
Massif snapshots. accumulatedtracedata.cpp updates per-allocation leaked bytes
only when pass!=FirstPass (allocation and free paths); totalCost.leaked is updated
in either pass. This explains observed nonzero total heap with zero-byte children
in the matching1.5.0 export. It is an upstream implementation mismatch, not a
Talos zero-allocation result. No profiler or Talos source has been changed.

Next approach: independently reconstruct live allocation bytes grouped by trace
from the existing interpreted format, with exact reconciliation to total heap
at every timestamp; or use a verified upstream exporter fix. Do not sum merged
peak reports or infer per-cache growth from empty trees. Existing finite total
heap observations remain distinct from the missing category attribution.
