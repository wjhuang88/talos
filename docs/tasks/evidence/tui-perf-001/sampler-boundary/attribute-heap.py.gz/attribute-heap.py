"""Diagnostic heaptrack v3 live-byte reconstruction; reconcile every timestamp."""
import json,re,collections,statistics
from pathlib import Path
from compression import zstd
root=Path(__file__).resolve().parent
source=root.parent/'bounded-segment-c386b362'
profile=source/'heap-transcript-commit.zst'
strings=[''];ips=[[]];traces=[(0,0)];infos=[];live=collections.Counter();snapshots=[];total=0;allocs=0;now=0
with zstd.open(profile,'rt') as f:
 for line in f:
  mode=line[0];parts=line.rstrip('\n').split(' ')
  if mode=='v': assert parts[2]=='3'
  elif mode=='s':
   _,size,text=line.rstrip('\n').split(' ',2);assert len(text.encode())==int(size,16);strings.append(text)
  elif mode=='i':
   values=[int(x,16) for x in parts[1:]];ips.append([strings[values[i]] for i in range(2,len(values),3)])
  elif mode=='t':traces.append(tuple(int(x,16) for x in parts[1:]))
  elif mode=='a':infos.append(tuple(int(x,16) for x in parts[1:]))
  elif mode in '+-':
   size,trace=infos[int(parts[1],16)];delta=size if mode=='+' else -size
   live[trace]+=delta;total+=delta;assert live[trace]>=0 and total>=0
   allocs+=mode=='+'
  elif mode=='c':
   now=int(parts[1],16)/1000
   assert sum(live.values())==total
   snapshots.append((now,total,dict(live) if 29.9<=now<=30.2 or 269.9<=now<=270.2 else None))
# Massif v1.5 FirstPass emits current total at the next timestamp. Verify all
# exported snapshots except its synthetic final timestamp, independently.
text=(source/'heap-transcript-commit-massif.txt').read_text()
expected=[(float(t),int(b)) for t,b in re.findall(r'time=([\d.]+)\nmem_heap_B=(\d+)',text)]
assert len(expected)>=len(snapshots)
for i,(t,total,_) in enumerate(snapshots): assert expected[i]==(t,total),(i,expected[i],(t,total))
def stack(trace):
 out=[]
 while trace:
  ip,trace=traces[trace];out.extend(ips[ip])
 return out
points=[]
for target in [30,270]:
 candidates=[x for x in snapshots if x[2] is not None and abs(x[0]-target)<=.2]
 points.append(min(candidates,key=lambda x:abs(x[0]-target)))
a,b=points;groups=collections.Counter();changes=[]
for trace in set(a[2])|set(b[2]):
 delta=b[2].get(trace,0)-a[2].get(trace,0)
 if not delta:continue
 frames=stack(trace)
 # Mutually exclusive attribution to the first symbol containing talos_tui (may be a generic allocator symbol).
 owner=next((f for f in frames if 'talos_tui' in f),'other')
 groups[owner]+=delta;changes.append(dict(trace=trace,delta_bytes=delta,frames=frames))
assert sum(groups.values())==b[1]-a[1]
result=dict(profile=str(profile),timestamp_checks=len(snapshots),allocation_count=allocs,total_heap_start=a[1],total_heap_end=b[1],start_seconds=a[0],end_seconds=b[0],delta_bytes=b[1]-a[1],group_deltas=dict(groups),trace_changes=sorted(changes,key=lambda x:abs(x['delta_bytes']),reverse=True),limits='Two time-point allocation-stack deltas, not Rust object ownership or universal leak freedom; groups are mutually exclusive first symbols containing talos_tui; generic allocator symbols can match.')
(root/'heap-attribution.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='trace_changes'},indent=2))

category_deltas=collections.Counter()
for change in changes:
 frames=' '.join(change['frames'])
 category=('history_projection' if 'history_projection' in frames else
           'stream_rendered_history' if 'StreamRenderState' in frames else
           'stream_opening_lines' if 'stream_opening_lines' in frames else 'unclassified')
 category_deltas[category]+=change['delta_bytes']
assert sum(category_deltas.values())==result['delta_bytes']
(root/'heap-categories.json').write_text(json.dumps(dict(path_deltas_bytes=dict(category_deltas),delta_bytes=result['delta_bytes'],classification='Mutually exclusive ordered stack membership: history_projection, StreamRenderState, stream_opening_lines, otherwise unclassified. Finite time-point allocation paths, not Rust object ownership.'),indent=2)+'\n')
