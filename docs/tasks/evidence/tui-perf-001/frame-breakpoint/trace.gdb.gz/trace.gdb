set pagination off
set confirm off
set startup-with-shell off
set disable-randomization off
set debuginfod enabled off
handle SIGPIPE nostop noprint pass
python
import gdb,json,time
from pathlib import Path
root=Path('/home/wjhuang/WorkSpace/personal/talos/target/tui-perf-artifacts/frame-breakpoint-294ebdc0')
pending={}
rows=[]
errors=[]
started=time.monotonic_ns()
def counters():
    pid,tid,_=gdb.selected_thread().ptid
    task=Path('/proc')/str(pid)/'task'/str(tid)
    stat=(task/'stat').read_text().rsplit(')',1)[1].split()
    sched=[int(v) for v in (task/'schedstat').read_text().split()]
    return tid,dict(runtime_ns=sched[0],runqueue_wait_ns=sched[1],major_faults=int(stat[9]),minor_faults=int(stat[7]))
class Boundary(gdb.Breakpoint):
    def __init__(self,line,start):
        super().__init__('crates/talos-tui/src/app/frame.rs:'+str(line),internal=True)
        self.start=start
    def stop(self):
        try:
            tid,c=counters()
            if self.start:
                pending[tid]=(time.monotonic_ns(),c)
            elif tid in pending:
                at,old=pending.pop(tid)
                if len(rows)<4096:
                    rows.append(dict(seconds=(at-started)/1e9,wall_ns=time.monotonic_ns()-at,**{k:c[k]-old[k] for k in c}))
        except Exception as e:
            if len(errors)<16:errors.append(type(e).__name__+': '+str(e))
        return False
Boundary(120,True)
Boundary(335,False)
end
run
python
(root/'frames.json').write_text(json.dumps(dict(frames=rows,errors=errors,unpaired=len(pending),limits='Intrusive GDB all-stop breakpoints at frame preparation boundaries. Wall time includes debugger resume/stop overhead; scheduler runtime/wait and faults are inferior thread deltas. Not acceptance timing, no inference about prior unobserved tail. Bounded to4096frames.'),indent=2)+'\n')
end
